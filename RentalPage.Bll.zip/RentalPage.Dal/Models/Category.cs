﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentalPage.Dal.Models
{
    public enum Category
    {
        CATEGORY_CLOTHING = 1,
        CATEGORY_SNOWBOARD = 2,
        CATEGORY_SKI = 3,
        CATEGORY_PROTECTIVEEQUIPMENTS = 4
    }


}
