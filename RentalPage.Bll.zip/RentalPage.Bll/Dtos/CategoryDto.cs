﻿namespace RentalPage.Bll.Dtos
{
    public enum CategoryDto
    {
        CATEGORY_CLOTHING,
        CATEGORY_SNOWBOARD,
        CATEGORY_SKI,
        CATEGORY_PROTECTIVEEQUIPMENTS
    }
}